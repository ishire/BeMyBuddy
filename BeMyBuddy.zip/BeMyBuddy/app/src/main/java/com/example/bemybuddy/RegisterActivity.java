package com.example.bemybuddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    private Button reg_button;
    private EditText fname;
    private EditText lname;
    private  EditText reg_email;
    private  EditText reg_pass;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        fname = (EditText) findViewById(R.id.fname);
        lname = (EditText) findViewById(R.id.lname);
        reg_email = (EditText) findViewById(R.id.emailreg);
        reg_pass =  (EditText) findViewById(R.id.passreg);
        reg_button = (Button) findViewById(R.id.reg_button);
        reg_button.setOnClickListener(this);





    }
    public void register(){
        final String user_email = reg_email.getText().toString().trim();
        String password = reg_pass.getText().toString().trim();
        String first_name = fname.getText().toString().trim();
        String last_name = lname.getText().toString().trim();

        // check for first name
        if (first_name.isEmpty()) {
            fname.setError("First name is required");
            fname.requestFocus();
            return;
        }

        // check for last name
        if (last_name.isEmpty()) {
            lname.setError("Last name is required");
            lname.requestFocus();
            return;
        }



        //checks if user email and password is empty and makes sure they are not.
        if (user_email.isEmpty()){
            reg_email.setError("Email is required");
            reg_email.requestFocus();
            return;
        }

        //checks if it is a correct email format.
        if (!Patterns.EMAIL_ADDRESS.matcher(user_email).matches()){
            reg_email.setError("Please enter a valid email!");
            reg_email.requestFocus();
            return;

        }
        //makes sure password is at least 6 letters long
        if (password.length() < 6){
            reg_pass.setError("Password must be at least 6 letters long!");
            reg_pass.requestFocus();
            return;
        }
    }
    @Override
    public void onClick(View v) {
        if (v == reg_button){
            Toast.makeText(this,"User Registered!", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, MainActivity.class));

        }

    }
}
